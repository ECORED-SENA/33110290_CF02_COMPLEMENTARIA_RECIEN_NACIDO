function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nIo4lMK6LH":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

